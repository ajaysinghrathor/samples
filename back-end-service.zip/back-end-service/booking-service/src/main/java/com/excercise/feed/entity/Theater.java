package com.excercise.feed.entity;

import javax.persistence.*;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;


@Table(name = "THEATER")
@Entity
@Access(AccessType.FIELD)
public class Theater implements Serializable {

    public Theater(){}
    @Id
    @Column(name = "id", nullable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;


    @OneToMany(targetEntity = Movie.class, mappedBy = "theater", fetch = FetchType.LAZY,
            cascade = CascadeType.ALL)
    private List<Movie> movies;

    @Column(name = "location")
    private Location location;


    @OneToMany(targetEntity = Screen.class, mappedBy = "theater", fetch = FetchType.LAZY,
            cascade = CascadeType.ALL)
    private List<Screen> screens;

    @OneToMany(targetEntity = Show.class, mappedBy = "theater", fetch = FetchType.LAZY,
            cascade = CascadeType.ALL)
    private List<Show> shows;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public List<Movie> getMovies() {
        return movies;
    }

    public void setMovies(List<Movie> movies) {
        this.movies = movies;
    }

    public Location getLocation() {
        return location;
    }

    public void setLocation(Location location) {
        this.location = location;
    }

    public List<Screen> getScreens() {
        return screens;
    }

    public void setScreens(List<Screen> screens) {
        this.screens = screens;
    }

    public List<Show> getShows() {
        return shows;
    }

    public void setShows(List<Show> shows) {
        this.shows = shows;
    }

}

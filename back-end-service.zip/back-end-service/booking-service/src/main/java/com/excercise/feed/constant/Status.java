package com.excercise.feed.constant;

public enum Status {
    IN_PROCESS,
    SUCCESS,
    FAIL;
}

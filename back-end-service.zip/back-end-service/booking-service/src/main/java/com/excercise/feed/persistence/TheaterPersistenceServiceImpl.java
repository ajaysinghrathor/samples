package com.excercise.feed.persistence;

import com.excercise.feed.entity.*;
import com.excercise.feed.repository.TheaterRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Service
public class TheaterPersistenceServiceImpl implements  TheaterPersistenceService{


    private @Autowired TheaterRepository theaterRepository;

    @Override
    public Theater save(Theater theater) {
        Theater saved  = theaterRepository.save(mockTheater());

        return saved;
    }

    @Override
    public List<Theater> searchTheaters() {
        ArrayList<Theater> theaters = new ArrayList<>();
        Theater theater = mockTheater();
        theaters.add(theater);
        return theaters;
    }

    @Override
    public Theater mockTheater(){
        Theater theater = new Theater();
        //theater.setId();
        theater.setLocation(mockLocation());
        theater.setMovies(mockMovie());
        return theater;
    }
    @Override
    public List<Movie> mockMovie() {
        ArrayList<Movie> movies = new ArrayList<>();
        Movie movie = new Movie();
        //movie.setId();
        movie.setLanguage("Hindi");
        //movie.setTheater(mockTheater());
        movie.setShows(mockShow());
        movie.setSeats(mockSeats());

        movies.add(movie);
        return movies;
     }
    @Override
    public List<Seat> mockSeats() {
        ArrayList<Seat> seats = new ArrayList<>();
        Seat seat = new Seat();
        //seat.setId();
        seat.setSeatName("A01");
        seat.setSeatRow("A");
        //seat.setScreen(mockScreen());
        seats.add(seat);
        return seats;
    }
    @Override
    public Screen mockScreen() {
        Screen screen = new Screen();
        //screen.setId();
        screen.setScreenName("Screen 1");
        //screen.setTheater(mockTheater());
        screen.setSeats(mockSeats());
        return screen;
    }
    @Override
    public List<Show> mockShow() {
        ArrayList<Show> shows = new ArrayList<>();
        Show show = new Show();
        //show.setId();
        //show.setTheater(mockTheater());
        //show.setMovie(mockMovie().get(0));
        show.setTiming(LocalDateTime.now());
        return shows;
    }
    @Override
    public Location mockLocation() {
        Location location = new Location();
        //location.setId();
        location.setCountry("india");
        location.setState("Uttar Pradesh");
        location.setCity("Noida");
        location.setPincode("201301");
        return location;
    }
}

package com.excercise.feed.repository;

import com.excercise.feed.entity.Screen;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

@RepositoryRestResource(collectionResourceRel = "theater", path = "theater")
public interface SeatRepository extends CrudRepository<Screen, Long> {
}

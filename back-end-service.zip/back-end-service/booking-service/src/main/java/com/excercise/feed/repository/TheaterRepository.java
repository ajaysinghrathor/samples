package com.excercise.feed.repository;

import com.excercise.feed.entity.FeedMetaData;
import com.excercise.feed.entity.Theater;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

@RepositoryRestResource(collectionResourceRel = "theater", path = "theater")
public interface TheaterRepository extends CrudRepository<Theater, Long>  {

}

package com.excercise.feed.persistence;

import com.excercise.feed.entity.*;

import java.util.List;

public interface TheaterPersistenceService {
    public Theater save(Theater theater);

    public List<Theater> searchTheaters();

    public Location mockLocation();
    public List<Show> mockShow();
    public Screen mockScreen();
    public List<Seat> mockSeats();
    public List<Movie> mockMovie();
    public Theater mockTheater();
}

package com.excercise.feed.entity;

import javax.persistence.*;
import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Table(name = "SHOW")
@Entity
@Access(AccessType.FIELD)
public class Show implements Serializable {
    public Show(){}

    @Id
    @Column(name = "id", nullable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    @Column(name = "movies")
    @ElementCollection(targetClass=Movie.class)
    private List<Movie> movies;

    @Column(name = "timing")
    private LocalDateTime timing;
    @Column(name = "isMorningShow")
    private boolean isMorningShow;
    @Column(name = "isAfterNoonShow")
    private boolean isAfterNoonShow;



    @Column(name = "isEveningShow")
    private boolean isEveningShow;
    @Column(name = "isNightShow")
    private boolean isNightShow;

    @ManyToOne(targetEntity = Theater.class, fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "theater_id", nullable = true)
    private Theater theater;

    @ManyToOne(targetEntity = Movie.class, fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "movie", nullable = true)

    private Movie movie;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public List<Movie> getMovies() {
        return movies;
    }

    public void setMovies(List<Movie> movies) {
        this.movies = movies;
    }

    public LocalDateTime getTiming() {
        return timing;
    }

    public void setTiming(LocalDateTime timing) {
        this.timing = timing;
    }

    public boolean isMorningShow() {
        return isMorningShow;
    }

    public void setMorningShow(boolean morningShow) {
        isMorningShow = morningShow;
    }

    public boolean isAfterNoonShow() {
        return isAfterNoonShow;
    }

    public void setAfterNoonShow(boolean afterNoonShow) {
        isAfterNoonShow = afterNoonShow;
    }

    public boolean isEveningShow() {
        return isEveningShow;
    }

    public void setEveningShow(boolean eveningShow) {
        isEveningShow = eveningShow;
    }

    public boolean isNightShow() {
        return isNightShow;
    }

    public void setNightShow(boolean nightShow) {
        isNightShow = nightShow;
    }

    public Theater getTheater() {
        return theater;
    }

    public void setTheater(Theater theater) {
        this.theater = theater;
    }

    public Movie getMovie() {
        return movie;
    }

    public void setMovie(Movie movie) {
        this.movie = movie;
    }

}

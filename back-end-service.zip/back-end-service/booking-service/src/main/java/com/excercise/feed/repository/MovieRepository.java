package com.excercise.feed.repository;

import com.excercise.feed.entity.Movie;
import com.excercise.feed.entity.Theater;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

@RepositoryRestResource(collectionResourceRel = "movie", path = "movie")
public interface MovieRepository extends CrudRepository<Movie, Long> {
}

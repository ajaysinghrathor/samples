package com.excercise.feed.service;


import com.excercise.feed.entity.*;

import com.excercise.feed.persistence.TheaterPersistenceService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.validation.constraints.NotNull;
import javax.ws.rs.*;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.MediaType;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;


@Component
@Path("/theaters")
public class BookingRestService {

    @Autowired
    private TheaterPersistenceService persistenceService;

    @GET
    @Path("/health")
    @Produces(MediaType.APPLICATION_JSON)
    @Operation(
            description = "List all people",
            responses = {
                    @ApiResponse(
                            content = @Content(
                                    array = @ArraySchema(schema = @Schema(implementation = Response.class))
                            ),
                            responseCode = "200"
                    )
            }
    )
    public Response health(){
        int status = 200;
        ArrayList<String> list = new ArrayList<String>();
        try{
            list.add("hello");
            list.add("add");
            if(false){
                status = 201;
            }
        }catch (Exception e){
            status = 500;
        }
        return Response
                .status(status)
                .header("Access-Control-Allow-Origin", "*")
                .header("Access-Control-Allow-Credentials", "true")
                .header("Access-Control-Allow-Headers",
                        "origin, content-type, accept, authorization")
                .header("Access-Control-Allow-Methods",
                        "GET, POST, PUT, DELETE, OPTIONS, HEAD")
                .entity(list)
                .build();
    }

    @GET
    @Path("/search")
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    public Response browseTheaters(
            @QueryParam("movie") String movie,
            @QueryParam("state") String state,
            @QueryParam("city") String city,
            @QueryParam("pincode") String pincode,
            @QueryParam("date") Date showTiming
            ){
        int status = 200;
        List<Theater> theaters = persistenceService.searchTheaters();
        try{
            if(theaters.isEmpty()){
                status = 201;
            }
        }catch (Exception e){
            status = 500;
        }
        return Response
                .status(status)
                .header("Access-Control-Allow-Origin", "*")
                .header("Access-Control-Allow-Credentials", "true")
                .header("Access-Control-Allow-Headers",
                        "origin, content-type, accept, authorization")
                .header("Access-Control-Allow-Methods",
                        "GET, POST, PUT, DELETE, OPTIONS, HEAD")
                .entity(theaters)
                .build();
    }


    @POST
    @Path("/create")
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    public Response createTheaters(Theater theater){
        int status = 200;
        Theater saveTheater = null;
        try{
            Location location = persistenceService.mockLocation();
            List<Seat> seats = persistenceService.mockSeats();
            Screen screen = persistenceService.mockScreen();
            List<Show> shows = persistenceService.mockShow();
            List<Movie> movies = persistenceService.mockMovie();
            Theater toSave = new Theater();
            toSave.setMovies(movies);
            toSave.setLocation(location);
            toSave.setShows(shows);
            toSave.setMovies(movies);

            saveTheater = persistenceService.save(toSave);
            if(saveTheater == null ||
                    (saveTheater != null && saveTheater.getId() == 0)){
                status = 500;
                saveTheater = theater;
                //Throw error Fail to save
            }
        }catch (Exception e){
            status = 500;
            saveTheater = theater;
        }
        return Response
                .status(status)
                .header("Access-Control-Allow-Origin", "*")
                .header("Access-Control-Allow-Credentials", "true")
                .header("Access-Control-Allow-Headers",
                        "origin, content-type, accept, authorization")
                .header("Access-Control-Allow-Methods",
                        "GET, POST, PUT, DELETE, OPTIONS, HEAD")
                .entity(saveTheater)
                .build();
    }

    @PUT
    @Path("/update")
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    public Response updateTheaters(@NotNull Theater theater){
        int status = 200;

        try{
            if(false){
                status = 201;
            }
        }catch (Exception e){
            status = 500;
        }
        return Response
                .status(status)
                .header("Access-Control-Allow-Origin", "*")
                .header("Access-Control-Allow-Credentials", "true")
                .header("Access-Control-Allow-Headers",
                        "origin, content-type, accept, authorization")
                .header("Access-Control-Allow-Methods",
                        "GET, POST, PUT, DELETE, OPTIONS, HEAD")
                .entity(theater)
                .build();
    }

    @DELETE
    @Path("/delete")
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    public Response deleteTheaters(@NotNull Theater theater){
        int status = 200;

        try{
            if(false){
                status = 201;
            }
        }catch (Exception e){
            status = 500;
        }
        return Response
                .status(status)
                .header("Access-Control-Allow-Origin", "*")
                .header("Access-Control-Allow-Credentials", "true")
                .header("Access-Control-Allow-Headers",
                        "origin, content-type, accept, authorization")
                .header("Access-Control-Allow-Methods",
                        "GET, POST, PUT, DELETE, OPTIONS, HEAD")
                .entity(theater)
                .build();
    }

}



package com.excercise.feed.config;

import com.excercise.feed.service.BookingRestService;
import com.excercise.feed.service.DataService;




import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.info.Info;
import io.swagger.v3.oas.annotations.info.License;
import org.glassfish.jersey.server.ResourceConfig;
import org.springframework.stereotype.Component;

import javax.ws.rs.ApplicationPath;

@Component
@ApplicationPath("api")
@OpenAPIDefinition(
        info = @Info(
                title = "XYZ Online Ticket Booking Api",
                version = "0.0.1-SNAPSHOT",
                license = @License(
                        name = "XYZ 2.0 License",
                        url = "http://www.xyz.org/licenses/LICENSE-2.0.html"
                )
        )
)
public class JerseyConfig extends ResourceConfig {

    public JerseyConfig() {
        configureSwagger();
        //packages(getClass().getPackage().getName(),
        //        ApiListingResource.class.getPackage().getName());

        registerEndpoints();
    }

    private void registerEndpoints() {
        register(BookingRestService.class);
        register(DataService.class);
    }

    private void configureSwagger() {

       // register(ApiListingResource.class);
       // BeanConfig beanConfig = new BeanConfig();
       // beanConfig.setVersion("1.0.2");
       // beanConfig.setSchemes(new String[]{"http"});
       // beanConfig.setHost("localhost:8080");
       // beanConfig.setBasePath("/api");
       // beanConfig.setResourcePackage("com.excercise.feed.service");
       // beanConfig.setPrettyPrint(true);
       // beanConfig.setScan(true);

        //SwaggerConfigLocator.getInstance().putConfig(SwaggerContextService.CONFIG_ID_DEFAULT, beanConfig);
    }
}

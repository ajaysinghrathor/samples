package com.excercise.feed.repository;

import com.excercise.feed.entity.Screen;
import com.excercise.feed.entity.Theater;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

@RepositoryRestResource(collectionResourceRel = "screen", path = "screen")
public interface ScreenRepostory extends CrudRepository<Screen, Long> {
}

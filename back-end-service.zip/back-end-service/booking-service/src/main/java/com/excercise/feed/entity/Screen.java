package com.excercise.feed.entity;

import javax.persistence.*;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

@Table(name = "SCREEN")
@Entity
@Access(AccessType.FIELD)
public class Screen implements Serializable {

    public Screen(){}

    @Id
    @Column(name = "id", nullable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    @Column(name = "seats")
    @OneToMany(targetEntity = Seat.class, mappedBy = "screen", fetch = FetchType.LAZY,
            cascade = CascadeType.ALL)
    private List<Seat> seats;

    @Column(name = "screenName")
    private String screenName;

    @ManyToOne(targetEntity = Theater.class, fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "theater_id", nullable = true)
    private Theater theater;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public List<Seat> getSeats() {
        return seats;
    }

    public void setSeats(List<Seat> seats) {
        this.seats = seats;
    }

    public String getScreenName() {
        return screenName;
    }

    public void setScreenName(String screenName) {
        this.screenName = screenName;
    }

    public Theater getTheater() {
        return theater;
    }

    public void setTheater(Theater theater) {
        this.theater = theater;
    }

}

package com.excercise.feed.constant;

import java.util.ArrayList;
import java.util.List;

public enum Fields {
    date,
    type,
    symbol,
    shares,
    price,
    costs,
    fees,
    amount,
    status,
    feedName;
}
